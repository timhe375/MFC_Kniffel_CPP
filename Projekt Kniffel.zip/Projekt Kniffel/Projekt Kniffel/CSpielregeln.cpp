// CSpielregeln.cpp: Implementierungsdatei
//

#include "pch.h"
#include "Projekt Kniffel.h"
#include "CSpielregeln.h"
#include "afxdialogex.h"

#include <string>
#include <fstream>


// CSpielregeln-Dialog

IMPLEMENT_DYNAMIC(CSpielregeln, CDialogEx)

CSpielregeln::CSpielregeln(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, Daten(_T(""))
{

}

CSpielregeln::~CSpielregeln()
{
}

void CSpielregeln::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, Daten);
}


BEGIN_MESSAGE_MAP(CSpielregeln, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CSpielregeln::OnBnClickedButton1)
END_MESSAGE_MAP()


// CSpielregeln-Meldungshandler


BOOL CSpielregeln::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	std::ifstream Datei("Regeln.txt");
	if (!Datei.good()) //Wenn �ffnen nicht geklappt hat
	{
		MessageBox("Fehler beim oeffnen der Datei");
		return 0;
	}

	Daten = "";

	std::string Zeile;
	while (Datei.good() && !Datei.eof())
	{
		std::getline(Datei, Zeile);
		Daten += Zeile.c_str();
		Daten += "\r\n";
	}

	Datei.close();
	UpdateData(0);
	// TODO: F�gen Sie hier Ihren Implementierungscode ein..
	return 0;
}


void CSpielregeln::OnBnClickedButton1()
{
	
	// TODO: F�gen Sie hier Ihren Handlercode f�r Benachrichtigungen des Steuerelements ein.
}

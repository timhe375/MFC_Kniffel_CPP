#pragma once

#include "pch.h"

// CSpielregeln-Dialog

class CSpielregeln : public CDialogEx
{
	DECLARE_DYNAMIC(CSpielregeln)

public:
	CSpielregeln(CWnd* pParent = nullptr);   // Standardkonstruktor
	virtual ~CSpielregeln();

// Dialogfelddaten
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterstützung

	DECLARE_MESSAGE_MAP()
public:
	BOOL OnInitDialog();
	CString Daten;
	afx_msg void OnBnClickedButton1();
};


// Projekt Kniffel.h: Hauptheaderdatei für die PROJECT_NAME-Anwendung
//

#pragma once

#ifndef __AFXWIN_H__
	#error "'pch.h' vor dieser Datei für PCH einschließen"
#endif

#include "resource.h"		// Hauptsymbole


// CProjektKniffelApp:
// Siehe Projekt Kniffel.cpp für die Implementierung dieser Klasse
//

class CProjektKniffelApp : public CWinApp
{
public:
	CProjektKniffelApp();

// Überschreibungen
public:
	virtual BOOL InitInstance();

// Implementierung

	DECLARE_MESSAGE_MAP()
};

extern CProjektKniffelApp theApp;

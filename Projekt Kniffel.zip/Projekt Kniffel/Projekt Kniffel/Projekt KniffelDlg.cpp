
// Projekt KniffelDlg.cpp: Implementierungsdatei
//

#include "pch.h"
#include "framework.h"
#include "Projekt Kniffel.h"
#include "Projekt KniffelDlg.h"
#include "afxdialogex.h"

#include <fstream>
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg-Dialogfeld für Anwendungsbefehl "Info"

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialogfelddaten
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterstützung

// Implementierung
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CProjektKniffelDlg-Dialogfeld



CProjektKniffelDlg::CProjektKniffelDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_PROJEKTKNIFFEL_DIALOG, pParent)
	, WH1(FALSE)
	, WH2(FALSE)
	, WH3(FALSE)
	, WH4(FALSE)
	, WH5(FALSE)
	, Einer(0)
	, Zweier(0)
	, Dreier(0)
	, DreierPash(0)
	, Vierer(0)
	, ViererPash(0)
	, Fuenfer(0)
	, Sechser(0)
	, Bonus(0)
	, Chance(0)
	, FullHouse(0)
	, Gesamt(0)
	, GrStr(0)
	, KlStr(0)
	, Kniffel(0)
	, Oben(0)
	, Unten(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	
}

void CProjektKniffelDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_WH1, WH1);
	DDX_Check(pDX, IDC_CHECK_WH2, WH2);
	DDX_Check(pDX, IDC_CHECK_WH3, WH3);
	DDX_Check(pDX, IDC_CHECK_WH4, WH4);
	DDX_Check(pDX, IDC_CHECK_WH5, WH5);
	DDX_Text(pDX, IDC_EDIT_1er, Einer);
	DDX_Text(pDX, IDC_EDIT_2er, Zweier);
	DDX_Text(pDX, IDC_EDIT_3er, Dreier);
	DDX_Text(pDX, IDC_EDIT_3erPash, DreierPash);
	DDX_Text(pDX, IDC_EDIT_4er, Vierer);
	DDX_Text(pDX, IDC_EDIT_4erPash, ViererPash);
	DDX_Text(pDX, IDC_EDIT_5er, Fuenfer);
	DDX_Text(pDX, IDC_EDIT_6er, Sechser);
	DDX_Text(pDX, IDC_EDIT_Bonus, Bonus);
	DDX_Text(pDX, IDC_EDIT_Chance, Chance);
	DDX_Text(pDX, IDC_EDIT_FullHouse, FullHouse);
	DDX_Text(pDX, IDC_EDIT_Gesamt, Gesamt);
	DDX_Text(pDX, IDC_EDIT_GrStr, GrStr);
	DDX_Text(pDX, IDC_EDIT_KlStr, KlStr);
	DDX_Text(pDX, IDC_EDIT_Kniffel, Kniffel);
	DDX_Text(pDX, IDC_EDIT_Oben, Oben);
	DDX_Text(pDX, IDC_EDIT_Unten, Unten);
	DDX_Control(pDX, IDC_W1, P_W1);
	DDX_Control(pDX, IDC_W2, P_W2);
	DDX_Control(pDX, IDC_W3, P_W3);
	DDX_Control(pDX, IDC_W4, P_W4);
	DDX_Control(pDX, IDC_W5, P_W5);
}

BEGIN_MESSAGE_MAP(CProjektKniffelDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_B_Wurf, &CProjektKniffelDlg::OnBnClickedBWurf)
	ON_BN_CLICKED(IDC_B_1er, &CProjektKniffelDlg::OnBnClickedB1er)
	ON_BN_CLICKED(IDC_B_2er, &CProjektKniffelDlg::OnBnClickedB2er)
	ON_BN_CLICKED(IDC_B_3er, &CProjektKniffelDlg::OnBnClickedB3er)
	ON_BN_CLICKED(IDC_B_4er, &CProjektKniffelDlg::OnBnClickedB4er)
	ON_BN_CLICKED(IDC_B_5er, &CProjektKniffelDlg::OnBnClickedB5er)
	ON_BN_CLICKED(IDC_B_6er, &CProjektKniffelDlg::OnBnClickedB6er)
	ON_BN_CLICKED(IDC_B_3erPash, &CProjektKniffelDlg::OnBnClickedB3erpash)
	ON_BN_CLICKED(IDC_B_4erPash, &CProjektKniffelDlg::OnBnClickedB4erpash)
	ON_BN_CLICKED(IDC_B_FullHouse, &CProjektKniffelDlg::OnBnClickedBFullhouse)
	ON_BN_CLICKED(IDC_B_KlStr, &CProjektKniffelDlg::OnBnClickedBKlstr)
	ON_BN_CLICKED(IDC_B_GrStr, &CProjektKniffelDlg::OnBnClickedBGrstr)
	ON_BN_CLICKED(IDC_B_Kniffel, &CProjektKniffelDlg::OnBnClickedBKniffel)
	ON_BN_CLICKED(IDC_B_Chance, &CProjektKniffelDlg::OnBnClickedBChance)
	ON_EN_CHANGE(IDC_EDIT_1er, &CProjektKniffelDlg::OnEnChangeEdit1er)
	ON_EN_CHANGE(IDC_EDIT_2er, &CProjektKniffelDlg::OnEnChangeEdit2er)
	ON_EN_CHANGE(IDC_EDIT_3er, &CProjektKniffelDlg::OnEnChangeEdit3er)
	ON_EN_CHANGE(IDC_EDIT_4er, &CProjektKniffelDlg::OnEnChangeEdit4er)
	ON_EN_CHANGE(IDC_EDIT_5er, &CProjektKniffelDlg::OnEnChangeEdit5er)
	ON_EN_CHANGE(IDC_EDIT_6er, &CProjektKniffelDlg::OnEnChangeEdit6er)
	ON_EN_CHANGE(IDC_EDIT_Oben, &CProjektKniffelDlg::OnEnChangeEditOben)
	ON_EN_CHANGE(IDC_EDIT_Bonus, &CProjektKniffelDlg::OnEnChangeEditBonus)
	ON_EN_CHANGE(IDC_EDIT_3erPash, &CProjektKniffelDlg::OnEnChangeEdit3erpash)
	ON_EN_CHANGE(IDC_EDIT_4erPash, &CProjektKniffelDlg::OnEnChangeEdit4erpash)
	ON_EN_CHANGE(IDC_EDIT_FullHouse, &CProjektKniffelDlg::OnEnChangeEditFullhouse)
	ON_EN_CHANGE(IDC_EDIT_KlStr, &CProjektKniffelDlg::OnEnChangeEditKlstr)
	ON_EN_CHANGE(IDC_EDIT_GrStr, &CProjektKniffelDlg::OnEnChangeEditGrstr)
	ON_EN_CHANGE(IDC_EDIT_Kniffel, &CProjektKniffelDlg::OnEnChangeEditKniffel)
	ON_EN_CHANGE(IDC_EDIT_Chance, &CProjektKniffelDlg::OnEnChangeEditChance)
	ON_EN_CHANGE(IDC_EDIT_Unten, &CProjektKniffelDlg::OnEnChangeEditUnten)
	ON_EN_CHANGE(IDC_EDIT_Gesamt, &CProjektKniffelDlg::OnEnChangeEditGesamt)
	ON_BN_CLICKED(IDC_B_NS, &CProjektKniffelDlg::OnBnClickedBNs)
	ON_BN_CLICKED(IDC_CHECK_WH1, &CProjektKniffelDlg::OnBnClickedCheckWh1)
	ON_BN_CLICKED(IDC_CHECK_WH2, &CProjektKniffelDlg::OnBnClickedCheckWh2)
	ON_BN_CLICKED(IDC_CHECK_WH3, &CProjektKniffelDlg::OnBnClickedCheckWh3)
	ON_BN_CLICKED(IDC_CHECK_WH4, &CProjektKniffelDlg::OnBnClickedCheckWh4)
	ON_BN_CLICKED(IDC_CHECK_WH5, &CProjektKniffelDlg::OnBnClickedCheckWh5)
	ON_BN_CLICKED(IDC_B_Spielregeln, &CProjektKniffelDlg::OnBnClickedBSpielregeln)
END_MESSAGE_MAP()


// CProjektKniffelDlg-Meldungshandler

BOOL CProjektKniffelDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Hinzufügen des Menübefehls "Info..." zum Systemmenü.

	// IDM_ABOUTBOX muss sich im Bereich der Systembefehle befinden.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Symbol für dieses Dialogfeld festlegen.  Wird automatisch erledigt
	//  wenn das Hauptfenster der Anwendung kein Dialogfeld ist
	SetIcon(m_hIcon, TRUE);			// Großes Symbol verwenden
	SetIcon(m_hIcon, FALSE);		// Kleines Symbol verwenden
	

	// TODO: Hier zusätzliche Initialisierung einfügen
	BYTE i = 0;
	for (i = 0; i <= 6; i++)
	{
		bmpWuerfel[i].LoadBitmap(IDB_BITMAP1 + i);
		m_icoZahl[i] = AfxGetApp()->LoadIcon(IDB_BITMAP1 - i);
	} 
	P_W1.SetBitmap(bmpWuerfel[0]);
	P_W2.SetBitmap(bmpWuerfel[0]);
	P_W3.SetBitmap(bmpWuerfel[0]);
	P_W4.SetBitmap(bmpWuerfel[0]);
	P_W5.SetBitmap(bmpWuerfel[0]);
	
	

	// Würfelbilder für Highscore Liste
	/*for (i = 0; i <= 5; i++)
	{
		m_dlgHsc.m_hZufallsIcon[i] = m_icoZahl[i + 1];
	}*/

	// Zufallszahlen-Generator Initialisieren
	srand(time(NULL));

	// Würfel auf Null setzten
	Wuerfel[0] = 0;
	Wuerfel[1] = 0;
	Wuerfel[2] = 0;
	Wuerfel[3] = 0;
	Wuerfel[4] = 0;


	return TRUE;  // TRUE zurückgeben, wenn der Fokus nicht auf ein Steuerelement gesetzt wird
}

void CProjektKniffelDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// Wenn Sie dem Dialogfeld eine Schaltfläche "Minimieren" hinzufügen, benötigen Sie
//  den nachstehenden Code, um das Symbol zu zeichnen.  Für MFC-Anwendungen, die das 
//  Dokument/Ansicht-Modell verwenden, wird dies automatisch ausgeführt.

void CProjektKniffelDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Gerätekontext zum Zeichnen

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Symbol in Clientrechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// Die System ruft diese Funktion auf, um den Cursor abzufragen, der angezeigt wird, während der Benutzer
//  das minimierte Fenster mit der Maus zieht.
HCURSOR CProjektKniffelDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}
















void CProjektKniffelDlg::OnBnClickedBWurf(void)
{
	
	int i = 0;
	WurfHalten();
	if (Wurf == 0)
	{
		// Schaltfläschen freigeben
		GetDlgItem(IDC_CHECK_WH1)->EnableWindow(true);
		GetDlgItem(IDC_CHECK_WH2)->EnableWindow(true);
		GetDlgItem(IDC_CHECK_WH3)->EnableWindow(true);
		GetDlgItem(IDC_CHECK_WH4)->EnableWindow(true);
		GetDlgItem(IDC_CHECK_WH5)->EnableWindow(true);

	}

	if (Wurf < 3)
	{
		// Werte der Würfel bestimmen
 		for (i = 0; i <= 4; i++)
		{
			if (Halten[i] == false)
				Wuerfel[i] = 1 + (rand() % 6);

			bmpWuerfel[i].Detach();
			bmpWuerfel[i].LoadBitmap(IDB_BITMAP1 + Wuerfel[i]);
			m_icoZahl[i] = AfxGetApp()->LoadIcon(IDB_BITMAP1 - Wuerfel[i]);
		}
		P_W1.SetBitmap(bmpWuerfel[0]);
		P_W2.SetBitmap(bmpWuerfel[1]);
		P_W3.SetBitmap(bmpWuerfel[2]);
		P_W4.SetBitmap(bmpWuerfel[3]);
		P_W5.SetBitmap(bmpWuerfel[4]);

		Wurf++;
	}
	if (Wurf == 3)
	{
		GetDlgItem(IDC_B_Wurf)->EnableWindow(false);

		// Halten der Würfel zurücksetzten
		WH1 = false;
		WH2 = false;
		WH3 = false;
		WH4 = false;
		WH5 = false;
		GetDlgItem(IDC_CHECK_WH1)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_WH2)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_WH3)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_WH4)->EnableWindow(false);
		GetDlgItem(IDC_CHECK_WH5)->EnableWindow(false);
		UpdateData(false);
		WurfHalten();
	}
	UpdateData(false);
	Invalidate();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}



















void CProjektKniffelDlg::OnBnClickedB1er()
{
	Einer = p1erbis6er(1);
	GetDlgItem(IDC_B_1er)->EnableWindow(FALSE);
	GetDlgItem(IDC_B_Wurf)->EnableWindow(TRUE);
	m_bTaste[0] = false;
	PunkteAuszaehlen();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedB2er()
{
	Zweier = p1erbis6er(2);
	GetDlgItem(IDC_B_2er)->EnableWindow(FALSE);
	GetDlgItem(IDC_B_Wurf)->EnableWindow(TRUE);
	m_bTaste[1] = false;
	PunkteAuszaehlen();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedB3er()
{
	Dreier = p1erbis6er(3);
	GetDlgItem(IDC_B_3er)->EnableWindow(FALSE);
	GetDlgItem(IDC_B_Wurf)->EnableWindow(TRUE);
	m_bTaste[2] = false;
	PunkteAuszaehlen();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedB4er()
{
	Vierer = p1erbis6er(4);
	GetDlgItem(IDC_B_4er)->EnableWindow(FALSE);
	GetDlgItem(IDC_B_Wurf)->EnableWindow(TRUE);
	m_bTaste[3] = false;
	PunkteAuszaehlen();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedB5er()
{
	Fuenfer = p1erbis6er(5);
	GetDlgItem(IDC_B_5er)->EnableWindow(FALSE);
	GetDlgItem(IDC_B_Wurf)->EnableWindow(TRUE);
	m_bTaste[4] = false;
	PunkteAuszaehlen();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedB6er()
{
	Sechser = p1erbis6er(6);
	GetDlgItem(IDC_B_6er)->EnableWindow(FALSE);
	GetDlgItem(IDC_B_Wurf)->EnableWindow(TRUE);
	m_bTaste[5] = false;
	PunkteAuszaehlen();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}

















void CProjektKniffelDlg::OnBnClickedB3erpash()
{
	DreierPash = pPash(3);
	GetDlgItem(IDC_B_3erPash)->EnableWindow(false);
	GetDlgItem(IDC_EDIT_3erPash)->ShowWindow(true);
	m_bTaste[6] = false;
	PunkteAuszaehlen();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedB4erpash()
{
	ViererPash = pPash(4);
	GetDlgItem(IDC_B_4erPash)->EnableWindow(false);
	GetDlgItem(IDC_EDIT_4erPash)->ShowWindow(true);
	m_bTaste[7] = false;
	PunkteAuszaehlen();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedBFullhouse()
{
	FullHouse = pFullhouse();
	GetDlgItem(IDC_B_FullHouse)->EnableWindow(false);
	GetDlgItem(IDC_EDIT_FullHouse)->ShowWindow(true);
	m_bTaste[8] = false;
	PunkteAuszaehlen();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedBKlstr()
{
	KlStr = pKlStr();
	GetDlgItem(IDC_B_KlStr)->EnableWindow(false);
	GetDlgItem(IDC_EDIT_KlStr)->ShowWindow(true);
	m_bTaste[9] = false;
	PunkteAuszaehlen();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedBGrstr()
{
	GrStr = pGrStr();
	GetDlgItem(IDC_B_GrStr)->EnableWindow(false);
	GetDlgItem(IDC_EDIT_GrStr)->ShowWindow(true);
	m_bTaste[10] = false;
	PunkteAuszaehlen();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedBKniffel()
{
	Kniffel = pPash(5);
	GetDlgItem(IDC_B_Kniffel)->EnableWindow(false);
	GetDlgItem(IDC_EDIT_Kniffel)->ShowWindow(true);
	m_bTaste[11] = false;
	PunkteAuszaehlen();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedBChance()
{
	Chance = pChance();
	GetDlgItem(IDC_B_Chance)->EnableWindow(false);
	GetDlgItem(IDC_EDIT_Chance)->ShowWindow(true);
	m_bTaste[12] = false;
	PunkteAuszaehlen();
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}























void CProjektKniffelDlg::OnEnChangeEdit1er()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEdit2er()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEdit3er()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEdit4er()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEdit5er()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEdit6er()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


























void CProjektKniffelDlg::OnEnChangeEdit3erpash()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEdit4erpash()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEditFullhouse()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEditKlstr()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEditGrstr()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEditKniffel()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEditChance()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}























void CProjektKniffelDlg::OnEnChangeEditOben()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEditBonus()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEditUnten()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnEnChangeEditGesamt()
{
	// TODO:  Falls dies ein RICHEDIT-Steuerelement ist, wird das Kontrollelement
	// diese Benachrichtigung nicht senden, es sei denn, Sie überschreiben die CDialogEx::OnInitDialog()-
	// Funktion und rufen CRichEditCtrl().SetEventMask() auf
	// mit dem ENM_CHANGE-Flag ORed in der Eingabe.

	// TODO:  Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}




















void CProjektKniffelDlg::OnBnClickedBNs()
{
	
	int i;

	// Schaltfläschen freigeben
	GetDlgItem(IDC_B_Wurf)->EnableWindow(true);
	GetDlgItem(IDC_B_1er)->EnableWindow(true);
	GetDlgItem(IDC_B_2er)->EnableWindow(true);
	GetDlgItem(IDC_B_3er)->EnableWindow(true);
	GetDlgItem(IDC_B_4er)->EnableWindow(true);
	GetDlgItem(IDC_B_5er)->EnableWindow(true);
	GetDlgItem(IDC_B_6er)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_1er)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_2er)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_3er)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_4er)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_5er)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_6er)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_Oben)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_Bonus)->EnableWindow(true);
	/*GetDlgItem(IDC_TOBEN)->EnableWindow(true);
	GetDlgItem(IDC_TBONUS)->EnableWindow(true);*/
	GetDlgItem(IDC_B_3erPash)->EnableWindow(true);
	GetDlgItem(IDC_B_4erPash)->EnableWindow(true);
	GetDlgItem(IDC_B_FullHouse)->EnableWindow(true);
	GetDlgItem(IDC_B_KlStr)->EnableWindow(true);
	GetDlgItem(IDC_B_GrStr)->EnableWindow(true);
	GetDlgItem(IDC_B_Kniffel)->EnableWindow(true);
	GetDlgItem(IDC_B_Chance)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_3erPash)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_4erPash)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_FullHouse)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_KlStr)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_GrStr)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_Kniffel)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_Chance)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_Unten)->EnableWindow(true);
	GetDlgItem(IDC_EDIT_Gesamt)->EnableWindow(true);
	/*GetDlgItem(IDC_TUNTEN)->EnableWindow(true);
	GetDlgItem(IDC_TGESAMT)->EnableWindow(true);*/
	GetDlgItem(IDC_CHECK_WH1)->EnableWindow(true);
	GetDlgItem(IDC_CHECK_WH2)->EnableWindow(true);
	GetDlgItem(IDC_CHECK_WH3)->EnableWindow(true);
	GetDlgItem(IDC_CHECK_WH4)->EnableWindow(true);
	GetDlgItem(IDC_CHECK_WH5)->EnableWindow(true);
	/*GetDlgItem(IDC_SPHILFE)->EnableWindow(true);*/

	// Schaltfläschenfreigabe Speichern für Spielhilfe
	for (i = 0; i < 13; i++)
	{
		m_bTaste[i] = true;
	}
	
	// Anzahl des Wurfes und des Durchganges auf 0 setzten
	Wurf = 0;
	Durchgang = 0;

	// Würfel auf 0 und anzeigen
	for (i = 0; i <= 4; i++)
	{
		Wuerfel[i] = 0;
	}
	/*Wuerfel[0] = 0;
	Wuerfel[1] = 0;
	Wuerfel[2] = 0;
	Wuerfel[3] = 0;
	Wuerfel[4] = 0;*/

	

	// Punkte zurücksetzten
	Einer = 0;
	Zweier = 0;
	Dreier = 0;
	Vierer = 0;
	Fuenfer = 0;
	Sechser = 0;
	Oben = 0;
	Bonus = 0;
	DreierPash = 0;
	ViererPash = 0;
	FullHouse = 0;
	KlStr = 0;
	GrStr = 0;
	Kniffel = 0;
	Chance = 0;
	Unten = 0;
	Gesamt = 0;


	// Steuerfelder zurücksetzen
	WH1 = false;
	WH2 = false;
	WH3 = false;
	WH4 = false;
	WH5 = false;
	UpdateData(false);
	WurfHalten();
	//OnSphilfe();
	GetDlgItem(IDC_CHECK_WH1)->EnableWindow(false);
	GetDlgItem(IDC_CHECK_WH2)->EnableWindow(false);
	GetDlgItem(IDC_CHECK_WH3)->EnableWindow(false);
	GetDlgItem(IDC_CHECK_WH4)->EnableWindow(false);
	GetDlgItem(IDC_CHECK_WH5)->EnableWindow(false);


	// Zufällig ein Icon für den Dialog setzten
	i = 1 + (rand() % 6);
	SetIcon(m_icoZahl[i], TRUE);
	SetIcon(m_icoZahl[i], FALSE);
	
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}






















void CProjektKniffelDlg::OnBnClickedCheckWh1()
{
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedCheckWh2()
{
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedCheckWh3()
{
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedCheckWh4()
{
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}


void CProjektKniffelDlg::OnBnClickedCheckWh5()
{
	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}

void CProjektKniffelDlg::WurfHalten()
{
	UpdateData(true);
	Halten[0] = WH1;
	Halten[1] = WH2;
	Halten[2] = WH3;
	Halten[3] = WH4;
	Halten[4] = WH5;
}

BYTE CProjektKniffelDlg::p1erbis6er(BYTE iWert)
{
	BYTE i = 0;
	BYTE e = 0;
	BYTE Punkte = 0;

	// wie oft ist [iWert] gewürfelt worden
	for (i = 0; i <= 4; i++)
	{
		if (Wuerfel[i] == iWert) e++;
	}

	Punkte = iWert * e;
	return Punkte;
}

void CProjektKniffelDlg::Wuerfel_anzeigen(CPaintDC* pdc)
{
	BYTE i;
	BITMAP bm[5];
	CDC dcMem;

	// Gerätekontext erzeugen, in den Bitmap geladen wird
	dcMem.CreateCompatibleDC(pdc);

	// Die 5 Würfel anzeigen
	for (i = 0; i < 5; i++)
	{
		// Geladene Bitmaps hohlen
		bmpWuerfel[Wuerfel[i]].GetBitmap(&bm[i]);

		// Bitmap in den kompatiblen Gerätekontext selectieren und in Dialogfeld kopieren
		dcMem.SelectObject(bmpWuerfel[Wuerfel[i]]);
		pdc->BitBlt(30 + (80 * i), 30, bm[i].bmWidth, bm[i].bmHeight, &dcMem, 0, 0, SRCCOPY);
	}
	// Gerätekontext löschen
	DeleteDC(dcMem);
}

void CProjektKniffelDlg::PunkteAuszaehlen()
{
	BYTE i = 0;

	// Daten Aktualisieren
	UpdateData(false);
	UpdateData(true);

	// Zusammenzählen
	Oben = Einer + Zweier + Dreier + Vierer + Fuenfer + Sechser;
	if (Oben >= 63) Bonus = 35;
	Unten = DreierPash + ViererPash + FullHouse + KlStr + GrStr + Kniffel + Chance;
	Gesamt = Oben + Unten + Bonus;

	// Steuerfelder zurücksetzen
	WH1 = false;
	WH2 = false;
	WH3 = false;
	WH4 = false;
	WH5 = false;
	GetDlgItem(IDC_B_Wurf)->EnableWindow(true);
	GetDlgItem(IDC_CHECK_WH1)->EnableWindow(false);
	GetDlgItem(IDC_CHECK_WH2)->EnableWindow(false);
	GetDlgItem(IDC_CHECK_WH3)->EnableWindow(false);
	GetDlgItem(IDC_CHECK_WH4)->EnableWindow(false);
	GetDlgItem(IDC_CHECK_WH5)->EnableWindow(false);

	// Durchgang erhöhen
	Durchgang++;

	// Wurf zurücksetzten
	Wurf = 0;

	// Neue Daten anzeigen
	UpdateData(false);

	// Würfel zurücksetzen und anzeigen
	for (i = 0; i <= 4; i++)
	{
		Wuerfel[i] = 0;
	}
	Invalidate();

	if (Durchgang == 13)
	{
		GetDlgItem(IDC_B_NS)->SetFocus();
		//GetDlgItem(IDC_SPHILFE)->EnableWindow(false);
		GetDlgItem(IDC_B_Wurf)->EnableWindow(false);

		/*m_dlgHsc.iAktuellePunktzahl = m_iGesamt;
		m_dlgHsc.bPunktePruefen = true;
		m_dlgHsc.DoModal();*/

	}
	else
	{
		// Focus auf 'Würfeln' setzen
		GetDlgItem(IDC_B_Wurf)->SetFocus();
	}
}

void CProjektKniffelDlg::Ordnen(BYTE& riW1, BYTE& riW2, BYTE& riW3, BYTE& riW4, BYTE& riW5)
{
	// & ... Variablen als Referenz übergeben (ändert die den Wert der übergeben Variable)
	BYTE i;
	BYTE iTmp[6];
	BYTE t;
	BYTE j;

	// Werte in eine Variable zum sortieren speichern
	iTmp[0] = riW1;
	iTmp[1] = riW2;
	iTmp[2] = riW3;
	iTmp[3] = riW4;
	iTmp[4] = riW5;
	iTmp[5] = 0;

	// erster Würfel = größte Zahl (Sortieren)
	for (j = 4; j != 0; j--)
	{
		for (i = 0; i <= j; i++)
		{
			if (iTmp[i] < iTmp[i + 1])
			{
				t = iTmp[i + 1];
				iTmp[i + 1] = iTmp[i];
				iTmp[i] = t;
			}
		}
	}

	// Werte sortiert zurückschreiben in Ausgangsvariable
	riW1 = iTmp[0];
	riW2 = iTmp[1];
	riW3 = iTmp[2];
	riW4 = iTmp[3];
	riW5 = iTmp[4];
}

BYTE CProjektKniffelDlg::pPash(BYTE iAnzahl)
{
	BYTE i = 0;
	BYTE j = 0;
	BYTE t = 0;
	BYTE e = 0;
	BYTE Punkte = 0;

	for (j = 1; j <= 6; j++)
	{
		for (i = 0; i <= 4; i++)		// wie oft ist [j] gewürfelt wurden
		{
			if (Wuerfel[i] == j) t++;
		}
		if (t >= iAnzahl)				// Anzahl der Würfe >= der Vorgabe?
		{
			for (i = 0; i <= 4; i++)		// alle Augen zusammenzählen
			{
				e = e + Wuerfel[i];
			}
			switch (iAnzahl)
			{
			case 3:
				Punkte = e;		// bei DreierPash alle Augen
				break;
			case 4:
				Punkte = e;		// bei ViererPash alle Augen
				break;
			case 5:
				Punkte = 50;	// bei Kniffel 50 
				break;
			}
		}
		t = 0;
	}
	return Punkte;
}

BYTE CProjektKniffelDlg::pChance()
{
	BYTE i = 0;
	BYTE Punkte = 0;

	// alle Augen zusammen zählen
	for (i = 0; i <= 4; i++)
	{
		Punkte = Punkte + Wuerfel[i];
	}

	return Punkte;
}

BYTE CProjektKniffelDlg::pGrStr()
{
	BYTE i;
	BYTE Punkte = 0;
	bool	t1 = true;
	bool t2 = true;
	BYTE tmpWuerfel[5];

	for (i = 0; i <= 4; i++)		// Werte zum bearbeiten zwischenspeichern
	{
		tmpWuerfel[i] = Wuerfel[i];
	}

	Ordnen(tmpWuerfel[0], tmpWuerfel[1], tmpWuerfel[2], tmpWuerfel[3], tmpWuerfel[4]);	// Werte Ordnen

	for (i = 0; i <= 4; i++)
	{
		t1 = t1 && (tmpWuerfel[i] == 6 - i);	// (6 bis 2)
		t2 = t2 && (tmpWuerfel[i] == 5 - i);	// (5 bis 1)
	}

	if (t1 || t2)Punkte = 40;		// (2 bis 6) oder (1 bis 5)

	return Punkte;
}

BYTE CProjektKniffelDlg::pKlStr()
{
	BYTE i = 0;
	BYTE j = 0;
	bool t = false;
	bool bZahl[7];
	BYTE Punkte = 0;

	// alles von bZahl auf false setzen
	for (i = 0; i <= 6; i++)
	{
		bZahl[i] = false;
	}

	// Zahlen übernehmen
	for (i = 0; i <= 4; i++)
	{
		bZahl[Wuerfel[i]] = true;
	}

	// vier aufeinander folgende Zahlen
	for (i = 0; i <= 3; i++)
	{
		if (bZahl[i] && bZahl[i + 1] && bZahl[i + 2] && bZahl[i + 3])
		{
			t = true;
			i = 4;		// aus der Schleife springen
		}
	}

	if (t) Punkte = 30;

	return Punkte;
}

BYTE CProjektKniffelDlg::pFullhouse()
{
	bool t1 = false;
	BYTE Punkte = 0;
	BYTE i = 0;
	BYTE tmpWuerfel[5];

	for (i = 0; i <= 4; i++)		// Werte zum bearbeiten zwischenspeichern
	{
		tmpWuerfel[i] = Wuerfel[i];
	}

	Ordnen(tmpWuerfel[0], tmpWuerfel[1], tmpWuerfel[2], tmpWuerfel[3], tmpWuerfel[4]);	// Werte Ordnen


	// zwei gleiche und drei gleiche
	if ((tmpWuerfel[0] + tmpWuerfel[1] + tmpWuerfel[2]) / 3 == tmpWuerfel[0])
	{
		if (((tmpWuerfel[3] + tmpWuerfel[4]) / 2 == tmpWuerfel[3]) && (tmpWuerfel[0] != 0)) Punkte = 25;
	}
	else
	{
		if (((tmpWuerfel[2] + tmpWuerfel[3] + tmpWuerfel[4]) / 3 == tmpWuerfel[2]) && (tmpWuerfel[0] != 0))
		{
			if ((tmpWuerfel[0] + tmpWuerfel[1]) / 2 == tmpWuerfel[0]) Punkte = 25;
		}
	}

	return Punkte;
}


void CProjektKniffelDlg::OnBnClickedBSpielregeln()
{
	Dialog_Spielregeln.DoModal();

	// TODO: Fügen Sie hier Ihren Handlercode für Benachrichtigungen des Steuerelements ein.
}

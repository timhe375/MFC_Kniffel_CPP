
// Projekt KniffelDlg.h: Headerdatei
//

#pragma once
#include "CSpielregeln.h"

// CProjektKniffelDlg-Dialogfeld
class CProjektKniffelDlg : public CDialogEx
{
// Konstruktion
public:
	CProjektKniffelDlg(CWnd* pParent = nullptr);	// Standardkonstruktor

// Dialogfelddaten
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PROJEKTKNIFFEL_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterstützung


// Implementierung
protected:
	HICON m_hIcon;
	

	// Generierte Funktionen für die Meldungstabellen
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	HICON m_icoZahl[7];
	BOOL WH1;
	BOOL WH2;
	BOOL WH3;
	BOOL WH4;
	BOOL WH5;
	BYTE Einer;
	BYTE Zweier;
	BYTE Dreier;
	BYTE DreierPash;
	BYTE Vierer;
	BYTE ViererPash;
	BYTE Fuenfer;
	BYTE Sechser;
	BYTE Bonus;
	BYTE Chance;
	BYTE FullHouse;
	int Gesamt;
	BYTE GrStr;
	BYTE KlStr;
	BYTE Kniffel;
	BYTE Oben;
	BYTE Unten;
	afx_msg void OnBnClickedBWurf();
	afx_msg void OnBnClickedB1er();
	afx_msg void OnBnClickedB2er();
	afx_msg void OnBnClickedB3er();
	afx_msg void OnBnClickedB4er();
	afx_msg void OnBnClickedB5er();
	afx_msg void OnBnClickedB6er();
	afx_msg void OnBnClickedB3erpash();
	afx_msg void OnBnClickedB4erpash();
	afx_msg void OnBnClickedBFullhouse();
	afx_msg void OnBnClickedBKlstr();
	afx_msg void OnBnClickedBGrstr();
	afx_msg void OnBnClickedBKniffel();
	afx_msg void OnBnClickedBChance();
	afx_msg void OnEnChangeEdit1er();
	afx_msg void OnEnChangeEdit2er();
	afx_msg void OnEnChangeEdit3er();
	afx_msg void OnEnChangeEdit4er();
	afx_msg void OnEnChangeEdit5er();
	afx_msg void OnEnChangeEdit6er();
	afx_msg void OnEnChangeEditOben();
	afx_msg void OnEnChangeEditBonus();
	afx_msg void OnEnChangeEdit3erpash();
	afx_msg void OnEnChangeEdit4erpash();
	afx_msg void OnEnChangeEditFullhouse();
	afx_msg void OnEnChangeEditKlstr();
	afx_msg void OnEnChangeEditGrstr();
	afx_msg void OnEnChangeEditKniffel();
	afx_msg void OnEnChangeEditChance();
	afx_msg void OnEnChangeEditUnten();
	afx_msg void OnEnChangeEditGesamt();
	afx_msg void OnBnClickedBNs();
	afx_msg void OnBnClickedCheckWh1();
	afx_msg void OnBnClickedCheckWh2();
	afx_msg void OnBnClickedCheckWh3();
	afx_msg void OnBnClickedCheckWh4();
	afx_msg void OnBnClickedCheckWh5();
	afx_msg void WurfHalten();

private:

	BYTE p1erbis6er(BYTE iWert);
	void Wuerfel_anzeigen(CPaintDC* pdc);
	void PunkteAuszaehlen();
	void Ordnen(BYTE& riW1, BYTE& riW2, BYTE& riW3, BYTE& riW4, BYTE& riW5);
	BYTE pPash(BYTE iAnzahl);
	BYTE pChance();
	BYTE pGrStr();
	BYTE pKlStr();
	BYTE pFullhouse();
	BOOL m_bTaste[13];
	BYTE Durchgang;
	BYTE Wurf;
	BYTE Wuerfel[5];
	BOOL Halten[5];
	CBitmap bmpWuerfel[7];
public:
	CStatic P_W1;
	CStatic P_W2;
	CStatic P_W3;
	CStatic P_W4;
	CStatic P_W5;
	CSpielregeln Dialog_Spielregeln;
	afx_msg void OnBnClickedBSpielregeln();
};

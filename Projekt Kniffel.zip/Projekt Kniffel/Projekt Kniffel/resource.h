//{{NO_DEPENDENCIES}}
// Von Microsoft Visual C++ generierte Includedatei.
// Verwendet durch ProjektKniffel.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PROJEKTKNIFFEL_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       130
#define IDI_ICON2                       132
#define IDI_ICON3                       133
#define IDI_ICON4                       134
#define IDI_ICON5                       135
#define IDI_ICON6                       136
#define IDI_ICON7                       137
#define IDB_BITMAP1                     138
#define IDB_BITMAP2                     139
#define IDB_BITMAP3                     140
#define IDB_BITMAP4                     141
#define IDB_BITMAP5                     142
#define IDB_BITMAP6                     143
#define IDB_BITMAP7                     144
#define IDD_DIALOG1                     146
#define IDC_B_1er                       1000
#define IDC_B_2er                       1001
#define IDC_B_3er                       1002
#define IDC_B_4er                       1003
#define IDC_B_5er                       1004
#define IDC_B_6er                       1005
#define IDC_B_3erPash                   1006
#define IDC_B_4erPash                   1007
#define IDC_B_FullHouse                 1008
#define IDC_B_KlStr                     1009
#define IDC_B_GrStr                     1010
#define IDC_B_Kniffel                   1011
#define IDC_B_Chance                    1012
#define IDC_EDIT_1er                    1013
#define IDC_EDIT_2er                    1014
#define IDC_EDIT_3er                    1015
#define IDC_EDIT_4er                    1016
#define IDC_EDIT_5er                    1017
#define IDC_EDIT_6er                    1018
#define IDC_EDIT_Oben                   1019
#define IDC_EDIT_Bonus                  1020
#define IDC_EDIT_3erPash                1021
#define IDC_EDIT_4erPash                1022
#define IDC_EDIT_FullHouse              1023
#define IDC_EDIT_KlStr                  1024
#define IDC_EDIT_GrStr                  1025
#define IDC_EDIT_Kniffel                1026
#define IDC_EDIT_Chance                 1027
#define IDC_EDIT_Unten                  1028
#define IDC_EDIT_Gesamt                 1029
#define IDC_B_Wurf                      1030
#define IDC_B_NS                        1031
#define IDC_CHECK_WH1                   1032
#define IDC_CHECK_WH2                   1033
#define IDC_CHECK_WH3                   1034
#define IDC_CHECK_WH4                   1035
#define IDC_CHECK_WH5                   1036
#define IDC_W1                          1037
#define IDC_W2                          1038
#define IDC_W3                          1039
#define IDC_W4                          1040
#define IDC_W5                          1041
#define IDC_B_Spielregeln               1042
#define IDC_BUTTON1                     1043
#define IDC_EDIT1                       1044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
